# ArabicGuy Mod Menu 4.05/1.00 ported to 6.72/1.27-1.32
Use HEN 2.13b/leeful.

## Credits:
### 2Much4u, GiantPluto, ArabicGuy, Specter, CTurt, qwertyoruiopz, flatz, idc, SKFU, droogie, Xerpi, bigboss, Hunger, Takezo, and Proxima
