#include "lib.h"
#include "natives.h"

#ifndef NULL
#define NULL 0
#endif

bool init = false;
int frameCount = 0;
bool selfoption[50];
bool selfWeapon[50];
bool Jetpack;
int intTest[50];
float floatTest[50];

int menuColours[25];

typedef union RGBA
{
	struct
	{
		union{int red; int r;};
		union{int green; int g;};
		union{int blue; int b;};
		union{int opacity; int alpha; int a;};
	};
	int col[4];
} RGBA;
typedef int rgba;


float menuXCoord = 0.845f;

int submenu = 0;
int submenuLevel;
int lastSubmenu[50];
int lastOption[50];
int currentOption;
int optionCount;
bool optionPress = false;
bool rightPress = false;
bool leftPress = false;
bool fastRightPress = false;
bool fastLeftPress = false;
bool squarePress = false;
int selectedPlayer;
bool menuSounds = true;
bool keyboardActive = false;
int keyboardAction;
int *keyboardVar = 0;
char *infoText;

bool newTimerTick = true;
int maxTimerCount;
bool newTimerTick2 = true;
int maxTimerCount2;

bool instructions = false;
int instructCount;
int mov;
bool instructionsSetupThisFrame;
bool xInstruction;
bool squareInstruction;
bool lrInstruction;

int bannerTextRed = 255;
int bannerTextGreen = 255;
int bannerTextBlue = 255;
int bannerTextOpacity = 255;
int bannerTextFont = 1;
int bannerRectRed = 15;
int bannerRectGreen = 15;
int bannerRectBlue = 100;
int bannerRectOpacity = 230;
int backgroundRed = 16;
int backgroundGreen = 16;
int backgroundBlue = 16;
int backgroundOpacity = 150;
int optionsRed = 255;
int optionsGreen = 255;
int optionsBlue = 255;
int optionsOpacity = 255;
int optionsFont = 0;
int scrollerRed = 15;
int scrollerGreen = 15;
int scrollerBlue = 100;
int scrollerOpacity = 230;
int indicatorRed = 255;
int indicatorGreen = 255;
int indicatorBlue = 255;
int indicatorOpacity = 255;
float textXCoord = 0.74f;
int maxOptions = 18;


void PRINT(char* Text, int MS)
{
  HUD::BEGIN_TEXT_COMMAND_PRINT("STRING");
  HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(Text);
  HUD::END_TEXT_COMMAND_PRINT(MS, true);
}

void set_text_component(char *text)
{
	GRAPHICS::BEGIN_TEXT_COMMAND_SCALEFORM_STRING("STRING");
	HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
	GRAPHICS::END_TEXT_COMMAND_SCALEFORM_STRING();
}

void instructionsSetup()
{
	mov = GRAPHICS::REQUEST_SCALEFORM_MOVIE("instructional_buttons");
	GRAPHICS::DRAW_SCALEFORM_MOVIE_FULLSCREEN(mov, 255, 255, 255, 0, 0);
	GRAPHICS::BEGIN_SCALEFORM_MOVIE_METHOD(mov, "CLEAR_ALL");
	GRAPHICS::END_SCALEFORM_MOVIE_METHOD();
	GRAPHICS::BEGIN_SCALEFORM_MOVIE_METHOD(mov, "SET_CLEAR_SPACE");
	GRAPHICS::SCALEFORM_MOVIE_METHOD_ADD_PARAM_INT(200);
	GRAPHICS::END_SCALEFORM_MOVIE_METHOD();
	instructCount = 0;
}
void addInstruction(int button, char *text)
{
	if (!instructionsSetupThisFrame)
	{
		instructionsSetup();
		instructionsSetupThisFrame = true;
	}
	GRAPHICS::BEGIN_SCALEFORM_MOVIE_METHOD(mov, "SET_DATA_SLOT");
	GRAPHICS::SCALEFORM_MOVIE_METHOD_ADD_PARAM_INT(instructCount);
	GRAPHICS::SCALEFORM_MOVIE_METHOD_ADD_PARAM_INT(button);
	set_text_component(text);
	GRAPHICS::END_SCALEFORM_MOVIE_METHOD();
	instructCount++;
}
void instructionsClose()
{
	GRAPHICS::BEGIN_SCALEFORM_MOVIE_METHOD(mov, "DRAW_INSTRUCTIONAL_BUTTONS");
	GRAPHICS::END_SCALEFORM_MOVIE_METHOD();
	GRAPHICS::BEGIN_SCALEFORM_MOVIE_METHOD(mov, "SET_BACKGROUND_COLOUR");
	GRAPHICS::SCALEFORM_MOVIE_METHOD_ADD_PARAM_INT(0);
	GRAPHICS::SCALEFORM_MOVIE_METHOD_ADD_PARAM_INT(0);
	GRAPHICS::SCALEFORM_MOVIE_METHOD_ADD_PARAM_INT(0);
	GRAPHICS::SCALEFORM_MOVIE_METHOD_ADD_PARAM_INT(80);
	GRAPHICS::END_SCALEFORM_MOVIE_METHOD();
}


void drawText(char * text, int font, float x, float y, float scalex, float scaley, int r, int b, int g, int a, bool center)
{
		HUD::SET_TEXT_FONT(font);
		HUD::SET_TEXT_SCALE(scalex, scaley);
		HUD::SET_TEXT_COLOUR(r, g, b, a);
		HUD::SET_TEXT_WRAP(0.0f, 1.0f);
		HUD::SET_TEXT_CENTRE(center);
		HUD::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		HUD::END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
}

void drawText1(char * text, int font, float x, float y, float scalex, float scaley, int r, int b, int g, int a, bool center)
{
		HUD::SET_TEXT_FONT(font);
		HUD::SET_TEXT_SCALE(scalex, scaley);
		HUD::SET_TEXT_COLOUR(r, g, b, a);
		HUD::SET_TEXT_WRAP(0.0f, 1.0f);
		//HUD::SET_TEXT_CENTRE(center);
		HUD::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		HUD::END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
}
void drawNotification(char* msg)
{
	if (menuXCoord == 0.845f)
	{
		HUD::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(msg);
		HUD::END_TEXT_COMMAND_THEFEED_POST_STATS("CHAR_SOCIAL_CLUB", "CHAR_SOCIAL_CLUB", true, 4, "Menu Base", "", 0);
		HUD::END_TEXT_COMMAND_THEFEED_POST_TICKER_WITH_TOKENS(false, true);
	}
	else
	{
		HUD::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(msg);
		HUD::END_TEXT_COMMAND_PRINT(3000, 1);
	}
}

void playSound(char* sound)
{
	if (menuSounds)
		AUDIO::PLAY_SOUND_FRONTEND(-1, sound, "HUD_FRONTEND_DEFAULT_SOUNDSET", false);
}
void startKeyboard(int action, char *defaultText, int maxLength)
{
	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "FMMC_KEY_TIP8", "", defaultText, "", "", "", maxLength);
	keyboardAction = action;
	keyboardActive = true;
}
void changeSubmenu(int newSubmenu)
{
        lastSubmenu[submenuLevel] = submenu;
	lastOption[submenuLevel] = currentOption;
	currentOption = 1;
	submenu = newSubmenu;
	submenuLevel++;
}


float GlobeX = 1.16424269f;
float GlobeY = 0.4180556f;
float GlobeH = 0.93f;
float GlobeG = 0.825f;
void drawGlare(float pX, float pY, float sX = 1, float sY = 1, int r = 255, int g = 255, int b = 255) 
{
	int gGlareHandle = GRAPHICS::REQUEST_SCALEFORM_MOVIE("MP_MENU_GLARE");
	GRAPHICS::DRAW_SCALEFORM_MOVIE(gGlareHandle, pX, pY, sX, sY, 255, 255, 255, 255, 0);
}
void addTitle(char *title)
{
	drawText1(title, 6, textXCoord, 0.063f, 1.0f, 1.0f, bannerTextRed, bannerTextGreen, bannerTextBlue, bannerTextOpacity, true);
	GRAPHICS::DRAW_RECT(menuXCoord, 0.0850f, 0.22f, 0.080f, bannerRectRed, bannerRectGreen, bannerRectBlue, bannerRectOpacity, 0);
	drawGlare(GlobeX, GlobeY, GlobeH, GlobeG, 255, 0, 93);
}

float menuXCoord1 = 0.754;
float menuXCoord3 = 0.915f;
char opt[100];
void addSubTitle(char *texting, char *Max_Case)
{
	char buffer[30];
	char Maxcases[100];
	snprintf(Maxcases, sizeof(Maxcases), " ~w~%i / ~w~%s", currentOption, Max_Case);
	drawText(Maxcases, 4, menuXCoord3, 0.127, 0.45, 0.45, bannerTextRed, bannerTextGreen, bannerTextBlue, bannerTextOpacity, false);
	drawText1(texting, 4, textXCoord, 0.127, 0.40, 0.40f, bannerTextRed, bannerTextGreen, bannerTextBlue, bannerTextOpacity, false);
	GRAPHICS::DRAW_RECT(menuXCoord, 0.1415, 0.22, 0.035f, 0, 0, 0, 190, 0);
}
float ONOFF = 0.94f;
bool x;
bool y;
bool width;
bool height;
bool rotation;
void DrawSprite(char  *Streamedtexture, char  *textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a)
{
	if (!GRAPHICS::HAS_STREAMED_TEXTURE_DICT_LOADED(Streamedtexture))
		GRAPHICS::REQUEST_STREAMED_TEXTURE_DICT(Streamedtexture, false);
	else
		GRAPHICS::DRAW_SPRITE(Streamedtexture, textureName, x, y, width, height, rotation, r, g, b, a, 0, 0);
}
float 
UpDown = .1135f, MenuWidth = .22f, SpriteWidht = .3420f, BHeight = 0.035f, one = 0.1420f, two = 0.0350, SPOZ = 0.94, checkboxshit = 0.875f;

int optionsRed2 = 0;
int optionsGreen2 = 0;
int optionsBlue2 = 0;

void addOption(char *option, char* spritedict, char* sprite, char *info = NULL)
{
	char buf[50];
	snprintf(buf, sizeof(buf), "%s", option);
	infoText = info;
	optionCount++;
	if (currentOption == optionCount)
	{
		if (currentOption <= maxOptions && optionCount <= maxOptions)
                {
			GRAPHICS::DRAW_RECT(menuXCoord, (optionCount * BHeight + one), MenuWidth, two, backgroundRed, backgroundGreen, backgroundBlue, backgroundOpacity, 0);
                        drawText(buf, optionsFont, textXCoord, (optionCount * 0.035f + 0.125f), 0.45f, 0.45f, optionsRed, optionsBlue, optionsGreen, optionsOpacity, false);
                        DrawSprite(spritedict, sprite, SPOZ, (optionCount * 0.035f + 0.1413f), 0.018, 0.028, 0, 255, 255, 255, 255);
                }
		else if ((optionCount > (currentOption - maxOptions)) && optionCount <= currentOption)
                {
			GRAPHICS::DRAW_RECT(menuXCoord, ((optionCount - (currentOption - maxOptions)) * BHeight + one), MenuWidth, two, backgroundRed, backgroundGreen, backgroundBlue, backgroundOpacity, 0);
                        drawText(buf, optionsFont, textXCoord, ((optionCount - (currentOption - maxOptions)) * 0.035f + 0.125f), 0.45f, 0.45f, optionsRed, optionsBlue, optionsGreen, optionsOpacity, false);
                        DrawSprite(spritedict, sprite, SPOZ, ((optionCount - (currentOption - maxOptions))* 0.035f + 0.1413f), 0.018, 0.028, 0, 255, 255, 255, 255); 
                }
	}
	else 
        {
		if (currentOption <= maxOptions && optionCount <= maxOptions)
                {
			GRAPHICS::DRAW_RECT(menuXCoord, (optionCount * BHeight + one), MenuWidth, two, backgroundRed, backgroundGreen, backgroundBlue, backgroundOpacity, 0); 
		        drawText(option, optionsFont, textXCoord, (optionCount * 0.035f + 0.125f), 0.4f, 0.4f, optionsRed, optionsGreen, optionsBlue, optionsOpacity, false);
                        DrawSprite(spritedict, sprite, SPOZ, (optionCount * 0.035f + 0.1413f), 0.018, 0.028, 0, 255, 255, 255, 255);
                }
		else if ((optionCount > (currentOption - maxOptions)) && optionCount <= currentOption)
                {
			GRAPHICS::DRAW_RECT(menuXCoord, ((optionCount - (currentOption - maxOptions)) * BHeight + one), MenuWidth, two, backgroundRed, backgroundGreen, backgroundBlue, backgroundOpacity, 0);  
                        drawText(option, optionsFont, textXCoord, ((optionCount - (currentOption - maxOptions)) * 0.035f + 0.125f), 0.4f, 0.4f, optionsRed, optionsGreen, optionsBlue, optionsOpacity, false);
                        DrawSprite(spritedict, sprite, SPOZ, ((optionCount - (currentOption - maxOptions)) * 0.035f + 0.1413f), 0.018, 0.028, 0, 255, 255, 255, 255);
                }
	}
}
float OnOff = 0.94f;

void addSubmenuOption(char *option, int newSubmenu, char* spritedict, char* sprite, char *info = NULL)
{
	addOption(option, spritedict, sprite, info);
	if (currentOption == optionCount)
	{
		xInstruction = true;
		if (optionPress)
			changeSubmenu(newSubmenu);
	}
}

void addBoolOption(char *option, bool *b00l, char* spritedict, char* sprite, char *info = NULL)
{
	char on[30];
	char off[30];
 	addOption(option, spritedict, sprite, info);
 	if(currentOption == optionCount && optionPress){
 		*b00l = !*b00l;
 	}
 	if (*b00l){
		int onr = 0;
		int ong = 255;
		int onb = 0;
		snprintf(on, sizeof(on), "O N", option);
		drawText(on, 4, textXCoord + .190, (optionCount * 0.035f + 0.123f), .57, .52, 0, 0, 255, 255, false);
 	}else{
		int offr = 255;
		int offg = 0;
		int offb = 0;
		snprintf(off, sizeof(off), "O F F", option);
		drawText(off, 4, textXCoord + .190, (optionCount * 0.035f + 0.123f), .57, .52, 255, 0, 0, 255, false);
 	}
}

void CheckBox(char *option, bool *b00l, char* spritedict, char* sprite, char *info = NULL)
{
        addOption(option, spritedict, sprite, info);
  	if(currentOption == optionCount && optionPress){
 		*b00l = !*b00l;
 	}
 	if (*b00l){
		DrawSprite("commonmenu", "common_medal", ONOFF, (optionCount * 0.035f + 0.1413f), 0.03, 0.04, 0,  0, 255, 0, 255);
        }else{
		DrawSprite("commonmenu", "common_medal", ONOFF, (optionCount * 0.035f + 0.1413f), 0.03, 0.04, 0, 255, 0, 0, 255);
        }
}
void CheckBox1(char *option, bool b00l, char* spritedict, char* sprite, char *info = NULL)
{
        addOption(option, spritedict, sprite, info);
  	if(currentOption == optionCount && optionPress){
 		b00l = !b00l;
 	}
 	if (b00l){
		DrawSprite("commonmenu", "common_medal", ONOFF, (optionCount * 0.035f + 0.1413f), 0.03, 0.04, 0,  0, 255, 0, 255);
        }else{
		DrawSprite("commonmenu", "common_medal", ONOFF, (optionCount * 0.035f + 0.1413f), 0.03, 0.04, 0, 255, 0, 0, 255);
        }
}
float Xpage3 = 0.95f, textright2 = 0.1280f;
int TypeMarkerRed = 127, TextColorRed = 249, TextColorBlue = 92, TextColorGreen = 8, R_Down = 127, G_Down = 13, B_Down = 240;
float BoolText = 0.93f;
float textright = 0.027;
float 
CharDraw1 = 0.9660f,
CharDraw2 = 0.126f,
CharDraw3 = 0.126f;
void drawText2(char * text, int font, float x, float y, float scalex, float scaley, float Wrap, int r, int b, int g, int a, bool center, bool right)
{
    HUD::SET_TEXT_FONT(font);
	HUD::SET_TEXT_SCALE(scalex, scaley);
	HUD::SET_TEXT_COLOUR(r, g, b, a);
	HUD::SET_TEXT_WRAP(0.0f, Wrap);
	HUD::SET_TEXT_CENTRE(center);
	HUD::SET_TEXT_RIGHT_JUSTIFY(right);
	HUD::SET_TEXT_DROPSHADOW(0, 0, 0, 0, 0);
	HUD::SET_TEXT_OUTLINE();
        HUD::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
	HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
	HUD::END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
}

void RightText(char* option)
{
    if (currentOption <= maxOptions && optionCount <= maxOptions)
	{
		drawText2(option, optionsFont, textright, (optionCount * 0.035f + textright2), 0.36f, 0.36f, Xpage3, optionsRed, optionsGreen, optionsBlue, optionsOpacity, false, true);
	}
	else if ((optionCount > (currentOption - maxOptions)) && optionCount <= currentOption)
	{
		drawText2(option, optionsFont, textright, ((optionCount - (currentOption - maxOptions)) * 0.035f + textright2), 0.36f, 0.36f, Xpage3, optionsRed, optionsGreen, optionsBlue, optionsOpacity, false, true);
	}
}
void drawFloat(float Val, bool center, bool right, float x, float y, float scalex, float scaley, int r, int b, int g, int a)
{
	HUD::SET_TEXT_FONT(0);
	HUD::SET_TEXT_SCALE(scalex, scaley);
	HUD::SET_TEXT_COLOUR(r, g, b, a);
	HUD::SET_TEXT_WRAP(0.0f, 0.95f);
	HUD::SET_TEXT_CENTRE(center);
        HUD::SET_TEXT_RIGHT_JUSTIFY(right);
	HUD::SET_TEXT_DROPSHADOW(0, 0, 0, 0, 0);
	HUD::SET_TEXT_OUTLINE();
	HUD::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("NUMBER");
	HUD::ADD_TEXT_COMPONENT_FLOAT(Val, 4);
	HUD::END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
}

float Movement = 0.001f, text1 = 0.160f, infobox = 0.180f;//0.125f
void addFloatOption(char *option, float *var, float min, float max, bool holdPress, char* spritedict, char* sprite, char *info = NULL)
{
    char buf[300];
	addOption(option, spritedict, sprite, info);
	if (currentOption <= maxOptions && optionCount <= maxOptions)
	{
	drawFloat(*var, false, true, textright, (optionCount  * 0.035f + textright2), 0.36f, 0.36f, 255, 255, 255, 255);
        snprintf(buf, sizeof(buf), "< %s >", *var);
	}
	else if ((optionCount > (currentOption - maxOptions)) && optionCount <= currentOption)
	{
	drawFloat(*var, false, true, textright, ((optionCount - (currentOption - maxOptions))  * 0.035f + textright2), 0.36f, 0.36f, 255, 255, 255, 255);
        snprintf(buf, sizeof(buf), "< %s >", *var);
	}
 	if (currentOption == optionCount)
	{
		if (holdPress)
		{
			if (fastRightPress)
			{
				playSound("NAV_UP_DOWN");
				if (*var >= max)
					*var = min;
				else
					*var = *var + Movement;
			}
			else if (fastLeftPress)
			{
				playSound("NAV_UP_DOWN");
				if (*var <= min)
					*var = max;
				else
					*var = *var - Movement;
			}
		}
		else
		{
			if (rightPress)
			{
				playSound("NAV_UP_DOWN");
				if (*var >= max)
					*var = min;
				else
					*var = *var + Movement;
			}
			else if (leftPress)
			{
				playSound("NAV_UP_DOWN");
				if (*var <= min)
					*var = max;
				else
					*var = *var - Movement;
			}     
                }
        }
	else 
        {
		snprintf(buf, sizeof(buf), "%s", *var);
	}
}


void addCharSwap(char *option, char **Default, int *var, int min, int max, bool fast, char* spritedict, char* sprite, char *info = NULL)
{
	char buf[10000];
	addOption(option, spritedict, sprite, info);
	if (currentOption == optionCount)
	{
		snprintf(buf, sizeof(buf), "<  %s  >", Default[*var], *var, max);
		RightText(buf);
                lrInstruction = true;
		if (rightPress)
		{
			playSound("NAV_UP_DOWN");
			if (*var >= max)
				*var = min;
			else
				*var = *var + 1;
		}
		else if (leftPress)
		{
			playSound("NAV_UP_DOWN");
			if (*var <= min)
				*var = max;
			else
				*var = *var - 1;
		}
	}
	else {
		snprintf(buf, sizeof(buf), "%s", Default[*var], *var, max);
		RightText(buf);
	}
}

void BoolRightText(char* option)
{
	if (currentOption <= maxOptions && optionCount <= maxOptions)
	{
		drawText2(option, optionsFont, 0.868, (optionCount * 0.035f + CharDraw2), 0.36f, 0.36f, BoolText, 255, 255, 255, 255, false, true);
	}
	else if ((optionCount > (currentOption - maxOptions)) && optionCount <= currentOption)
	{
		drawText2(option, optionsFont, 0.868, ((optionCount - (currentOption - maxOptions)) * 0.035f + CharDraw2), 0.36f, 0.36f, BoolText, 255, 255, 255, 255, false, true);
	}
}
void addCharBool(char *option, char **Default, int *var, int min, int max, bool fast, char *spritedict, char* sprite, bool *b00l, char *info = NULL)
{
	char buf[300];
	addOption(option, spritedict, sprite, info);
  	if(currentOption == optionCount && optionPress){
 		*b00l = !*b00l;
 	}
 	if (*b00l)
	{
	        DrawSprite("commonmenu", "common_medal", ONOFF, (optionCount * 0.035f + 0.1413f), 0.03, 0.04, 0,  0, 255, 0, 255);
        }
        else
        {
		DrawSprite("commonmenu", "common_medal", ONOFF, (optionCount * 0.035f + 0.1413f), 0.03, 0.04, 0, 255, 0, 0, 255);
        }
	if (currentOption == optionCount)
	{
		snprintf(buf, sizeof(buf), "<  %s  >", Default[*var], *var, max);
		BoolRightText(buf);
		if (rightPress)
		{
			playSound("NAV_UP_DOWN");
			if (*var >= max)
				*var = min;
			else
				*var = *var + 1;
		}
		else if (leftPress)
		{
			playSound("NAV_UP_DOWN");
			if (*var <= min)
				*var = max;
			else
				*var = *var - 1;
		}
	}
	else {
		snprintf(buf, sizeof(buf), "%s", Default[*var], *var, max);
		BoolRightText(buf);
	}
}
void addIntOption(char *option, int *var, int min, int max, bool fastScroll, char* spritedict, char* sprite, char *info = NULL)
{
	char buf[30];
	snprintf(buf, sizeof(buf)," < %i >", *var);
	RightText(buf);
	addOption(option, spritedict, sprite, info);
	if (currentOption == optionCount)
	{
		lrInstruction = true;
	
		if(fastScroll){
			if (fastRightPress)
		{
			playSound("NAV_UP_DOWN");
			if (*var >= max)
				*var = min;
			else
				*var = *var += 1;
		}
		else if (fastLeftPress)
		{
			playSound("NAV_UP_DOWN");
			if (*var <= min)
				*var = max;
			else
				*var = *var -= 1;
		}
		}else{
			if (rightPress)
		{
			playSound("NAV_UP_DOWN");
			if (*var >= max)
				*var = min;
			else
				*var = *var + 1;
		}
		else if (leftPress)
		{
			playSound("NAV_UP_DOWN");
			if (*var <= min)
				*var = max;
			else
				*var = *var - 1;
		}
		}
	}
}



int getOption()
{
	xInstruction = true;
	if (optionPress)
		return currentOption;
	else return 0;
}
bool featureBigMPMessge;
int SFBigMPMessage;
int featureTimeMPMessage = 0, _BigMPMessagetime = 0;
char *BigMPMessagemgs;
char *BigMPMessagedesc;
bool firstopenmenu = false;
void MPMESSAGE(char *msg, char *desc)
{
 featureBigMPMessge = true;
 BigMPMessagemgs = msg;
 BigMPMessagedesc = desc;
 AUDIO::PLAY_SOUND_FRONTEND(-1, "RACE_PLACED", "HUD_AWARDS", false);
}
void monitorButtons()
{
	if (submenu == Closed)
	{
		
			if (PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_X) && PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_LEFT))
			{
				submenu = Main_Menu;
				submenuLevel = 0;
				currentOption = 1;
				playSound("YES");
                                instructions = true;
                                if (firstopenmenu == false)
			        {
				MPMESSAGE("~g~Welcome"," ~w~To ~b~GraFfiX ~w~1.46 Base");
                                firstopenmenu = true;
			}
		}
	}
	else {
			if (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, INPUT_FRONTEND_CANCEL))
			{
				if (submenu == Main_Menu)
				{
					submenu = Closed;
                                        instructions = false;
				}
				else
				{
					submenu = lastSubmenu[submenuLevel - 1];
					currentOption = lastOption[submenuLevel - 1];
					submenuLevel--;
				}
				playSound("Back");
			}
			else if (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, INPUT_FRONTEND_ACCEPT))
			{
				optionPress = true;
				playSound("SELECT");
			}
			else if (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, INPUT_FRONTEND_UP))
			{
				currentOption--;
				if (currentOption < 1)
				{
					currentOption = optionCount;
				}
				playSound("NAV_UP_DOWN");
			}
			else if (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, INPUT_FRONTEND_DOWN))
			{
				currentOption++;
				if (currentOption > optionCount)
				{
					currentOption = 1;
				}
				playSound("NAV_UP_DOWN");
			}
			else if (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, INPUT_FRONTEND_RIGHT))
			{
				rightPress = true;
			}
			else if (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, INPUT_FRONTEND_LEFT))
			{
				leftPress = true;
			}
			else if (PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_RIGHT))
			{
				fastRightPress = true;
			}
			else if (PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_LEFT))
			{
				fastLeftPress = true;
			}
			else if (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, INPUT_FRONTEND_X))
			{
				squarePress = true;
			}
	       }
	       if (instructions) 
               {
	       if (xInstruction) {
			addInstruction(Scaleform_Button_X, "Select");
	       }
		if (squareInstruction) {
			addInstruction(Scaleform_Button_Square, "Keyboard");
		}
		if (lrInstruction) {
			addInstruction(Scaleform_Button_Dpad_Left_Right, "Scroll");
		}
		addInstruction(Scaleform_Button_Dpad_Up_Down, "Scroll");
		addInstruction(Scaleform_Button_Circle, (submenu == Main_Menu) ? "Close" : "Back");
		   instructionsClose();
               }
}
void normalMenuActions()
{
	PAD::DISABLE_CONTROL_ACTION(0, INPUT_FRONTEND_UP, true);
	PAD::DISABLE_CONTROL_ACTION(0, INPUT_FRONTEND_DOWN, true);
	PAD::DISABLE_CONTROL_ACTION(0, INPUT_FRONTEND_RIGHT, true);
	PAD::DISABLE_CONTROL_ACTION(0, INPUT_FRONTEND_LEFT, true);
	PAD::DISABLE_CONTROL_ACTION(0, INPUT_FRONTEND_ACCEPT, true);
	PAD::DISABLE_CONTROL_ACTION(0, INPUT_FRONTEND_CANCEL, true);
	PAD::DISABLE_CONTROL_ACTION(0, INPUT_FRONTEND_X, true);
	PAD::SET_INPUT_EXCLUSIVE(0, INPUT_FRONTEND_UP);
	PAD::SET_INPUT_EXCLUSIVE(0, INPUT_FRONTEND_RIGHT);
	PAD::SET_INPUT_EXCLUSIVE(0, INPUT_FRONTEND_LEFT);
	PAD::SET_INPUT_EXCLUSIVE(0, INPUT_FRONTEND_CANCEL);
        if (optionCount > maxOptions)
	{
                DrawSprite("commonmenu", "shop_arrows_upanddown", menuXCoord, ((maxOptions + 1) * 0.035f + 0.1415f), 0.02, 0.04, 0, 255, 255, 255, 255); //Down Icon

		if (currentOption > maxOptions)
		{
			DrawSprite("timerbars", "all_white_bg", menuXCoord, ((maxOptions * 0.035f) + 0.1415f), MenuWidth, 0.035f, 180, scrollerRed, scrollerGreen, scrollerBlue, scrollerOpacity);
		}
		else
		{
			DrawSprite("timerbars", "all_white_bg", menuXCoord, ((currentOption * 0.035f) + 0.1415f), MenuWidth, 0.035f, 180, scrollerRed, scrollerGreen, scrollerBlue, scrollerOpacity);
		}
		if (currentOption != optionCount)
		{
			//GRAPHICS::DRAW_RECT(menuXCoord, ((maxOptions * 0.035f) + 0.161f), 0.23f, 0.005f, indicatorRed, indicatorGreen, indicatorBlue, indicatorOpacity);//Down Indicator
		}
		//GRAPHICS::DRAW_RECT(menuXCoord, (((maxOptions * 0.035f) / 2) + 0.159f), 0.22f, (maxOptions * 0.035f), backgroundRed, backgroundGreen, backgroundBlue, backgroundOpacity);//Background

	}
	else
	{
		
		GRAPHICS::DRAW_RECT(menuXCoord, (((optionCount + 1) * 0.035f) + 0.1415f), 0.22f, 0.035f,  bannerRectRed, bannerRectGreen, bannerRectBlue, bannerRectOpacity, 0);//bottom rec
                DrawSprite("timerbars", "all_white_bg", menuXCoord, ((currentOption * 0.035f) + 0.1415f), MenuWidth, 0.035f, 180, scrollerRed, scrollerGreen, scrollerBlue, scrollerOpacity);
	}
	if (!MISC::IS_STRING_NULL_OR_EMPTY(infoText))
	{
		if (optionCount > maxOptions)
		{
			GRAPHICS::DRAW_RECT(menuXCoord, (((maxOptions + 1) * 0.035f) + 0.1415f), 0.22f, 0.035f,  bannerRectRed, bannerRectGreen, bannerRectBlue, bannerRectOpacity, 0);
                        DrawSprite("commonmenu", "shop_arrows_upanddown", menuXCoord, (((maxOptions + 1) * 0.035f) + 0.1415f), 0.02f, 0.04f, 0, 255, 255, 255, 255); //Info Box

		}
		else
		{
			GRAPHICS::DRAW_RECT(menuXCoord, (((optionCount + 1) * 0.035f) + 0.1415f), 0.22f, 0.035f, bannerRectRed, bannerRectGreen, bannerRectBlue, bannerRectOpacity, 0);
                   
                        DrawSprite("commonmenu", "shop_arrows_upanddown", menuXCoord, ((optionCount + 1) * 0.035f + 0.1415f), 0.02, 0.04, 0, 255, 255, 255, 255); //Down Icon

		}
	}
}
void resetVars()
{
	if (submenu != Closed)
		normalMenuActions();
	optionPress = false;
	rightPress = false;
	leftPress = false;
	fastRightPress = false;
	fastLeftPress = false;
	squarePress = false;
	infoText = NULL;
	instructionsSetupThisFrame = false;
	squareInstruction = false;
	xInstruction = false;
	lrInstruction = false;
}


void otherLoop()
{
if (keyboardActive) 
{ 
   if (MISC::UPDATE_ONSCREEN_KEYBOARD() == 1) 
   { 
      keyboardActive = false;
      switch (keyboardAction)
      {
       case 0:  break;
       case 1:  break;
       case 2:  break;
       case 3:  break;
       case 4: break;
       case 5: break;
       case 6: break;
       case 7:  break;
       case 8:  break;
       case 9:  break;
       case 10:  break;
       } 
} 
else if (MISC::UPDATE_ONSCREEN_KEYBOARD() == 2 || MISC::UPDATE_ONSCREEN_KEYBOARD() == 3) 
{ 
      keyboardActive = false; 
      }
}
if (featureBigMPMessge) { if (!GRAPHICS::HAS_SCALEFORM_MOVIE_LOADED(SFBigMPMessage)) SFBigMPMessage = GRAPHICS::REQUEST_SCALEFORM_MOVIE("MP_BIG_MESSAGE_FREEMODE"); else { if (MISC::GET_GAME_TIMER() > featureTimeMPMessage) { /*featureTimeMPMessage = MISC::GET_GAME_TIMER() + 20;*/ GRAPHICS::BEGIN_SCALEFORM_MOVIE_METHOD(SFBigMPMessage, "SHOW_SHARD_CREW_RANKUP_MP_MESSAGE"); /*SHOW_SHARD_CENTERED_TOP_MP_MESSAGE*/ set_text_component(BigMPMessagemgs); set_text_component(BigMPMessagedesc); GRAPHICS::END_SCALEFORM_MOVIE_METHOD(); GRAPHICS::DRAW_SCALEFORM_MOVIE_FULLSCREEN(SFBigMPMessage, 255, 255, 255, 255, 0); if (_BigMPMessagetime == 150) { GRAPHICS::BEGIN_SCALEFORM_MOVIE_METHOD(SFBigMPMessage, "TRANSITION_UP"); GRAPHICS::END_SCALEFORM_MOVIE_METHOD(); GRAPHICS::SET_SCALEFORM_MOVIE_AS_NO_LONGER_NEEDED(&SFBigMPMessage); featureBigMPMessge = false; _BigMPMessagetime = 0; } else _BigMPMessagetime++; }}}


if (selfoption[1]) { ENTITY::SET_ENTITY_HEALTH(PLAYER::PLAYER_PED_ID(), PED::GET_PED_MAX_HEALTH(PLAYER::PLAYER_PED_ID()), 0); PED::SET_PED_ARMOUR(PLAYER::PLAYER_PED_ID(), PLAYER::GET_PLAYER_MAX_ARMOUR(PLAYER::PLAYER_ID())); ENTITY::SET_ENTITY_CAN_BE_DAMAGED(PLAYER::PLAYER_PED_ID(), 0); ENTITY::SET_ENTITY_PROOFS(PLAYER::PLAYER_PED_ID(), 1, 1, 1, 1, 1, 1, 1, 1); ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), true); PED::SET_PED_CAN_RAGDOLL(PLAYER::PLAYER_PED_ID(), 0); PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(PLAYER::PLAYER_PED_ID(), 0); PED::SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(PLAYER::PLAYER_PED_ID(), 1); } else { ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), 0); ENTITY::SET_ENTITY_CAN_BE_DAMAGED(PLAYER::PLAYER_PED_ID(), 1); ENTITY::SET_ENTITY_PROOFS(PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 0, 0); ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), false); PED::SET_PED_CAN_RAGDOLL(PLAYER::PLAYER_PED_ID(), 1); PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(PLAYER::PLAYER_PED_ID(), 1); PED::SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(PLAYER::PLAYER_PED_ID(), 0); }
if (selfoption[2]) { PLAYER::SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(PLAYER::PLAYER_ID(), 1.49); } else{ PLAYER::SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(PLAYER::PLAYER_ID(), 1.00); }
if (selfoption[3]) { MISC::SET_SUPER_JUMP_THIS_FRAME(PLAYER::PLAYER_ID());}
if (selfoption[4]) { MISC::SET_EXPLOSIVE_MELEE_THIS_FRAME(PLAYER::PLAYER_ID());}
if (selfoption[5]) { ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(),false, false); } else { ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(),true, true); }
if (selfoption[6]) { PLAYER::CLEAR_PLAYER_WANTED_LEVEL(PLAYER::PLAYER_ID()); }




}
int Frame_Count;
int Hook()
{
        if (Frame_Count < MISC::GET_FRAME_COUNT());
        {
        Frame_Count = MISC::GET_FRAME_COUNT();
	monitorButtons();
        otherLoop();
	optionCount = 0;
        if(submenu == Main_Menu)
	{
	     addTitle("GraFfiX");
	     addSubTitle("M A I N   M E N U", "14");
             addSubmenuOption("Self Options",Self_Options, "commonmenutu", "custom_mission", " ");
             addSubmenuOption("Weapon Editor", Weapon_Editor, "commonmenutu", "custom_mission", " ");
	     addSubmenuOption("Spawn Vehicle", Spawn_Vehicle, "commonmenutu", "custom_mission", " ");
	     addSubmenuOption("Modded Vehicles", Modded_Vehicles, "commonmenutu", "custom_mission", " ");
	            addOption("Vehicle Options", "", " ");
	     addSubmenuOption("Traffic Options",Traffic_Options, "commonmenutu", "custom_mission", " ");
	     addSubmenuOption("Teleport Options",Teleport_Options, "commonmenutu", "custom_mission", " ");
	     addSubmenuOption("Spawn Map Objects",Spawn_Map_Objects, "commonmenutu", "custom_mission", " ");
             addSubmenuOption("Custom Ramps",Custom_Ramps, "commonmenutu", "custom_mission", " ");
	     addSubmenuOption("Spawn Peds Menu",Spawn_Peds_Menu, "commonmenutu", "custom_mission", " ");
             addSubmenuOption("Players List",Players_List, "commonmenutu", "custom_mission", " ");
             addSubmenuOption("Weather/Time",Weather_Time, "commonmenutu", "custom_mission", " ");
             addSubmenuOption("World/Lobby",World_Lobby, "commonmenutu", "custom_mission", " ");
	     switch (getOption())
	     {
		    case 5: if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), true)) { changeSubmenu(Vehicle_Options); } else { PRINT("Must Be In Vehicle To Open Vehicle Options Menu", 2000); } break;	     
             }
	}
        else if(submenu == Self_Options)
	{
             addTitle("GraFfiX");
	     addSubTitle("S E L F   M O D Z", "3");
             CheckBox("God Mode", &selfoption[1], " ", " ", "  ");
	     CheckBox("Super Run", &selfoption[2], " ", " ", "  ");
             CheckBox("Super Jump", &selfoption[3], " ", " ", " ");
	     CheckBox("Super Punch", &selfoption[4], " ", " ");
	     CheckBox("Invisibility",&selfoption[5]," ", " "); 
	     CheckBox("Never Wanted", &selfoption[6]," ", " ");
	     addOption("Clean Player"," ", " ");
	     addOption("Clean Player Area"," ", " ");
	     switch (getOption())
	     { 
		    case 8: PED::CLEAR_PED_BLOOD_DAMAGE(PLAYER::PLAYER_PED_ID()); PED::RESET_PED_VISIBLE_DAMAGE(PLAYER::PLAYER_PED_ID()); PRINT("Player: ~g~Cleaned", 2000); break;
		    case 9:
                       Vector3 MyPos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true); 
                       MISC::CLEAR_AREA(MyPos.x, MyPos.y, MyPos.z, 250, true, 0, 0, 0); 
                       MISC::CLEAR_AREA_OF_COPS(MyPos.x, MyPos.y, MyPos.z, 250, 0); 
                       MISC::CLEAR_AREA_OF_OBJECTS(MyPos.x, MyPos.y, MyPos.z, 250, 0); 
                       MISC::CLEAR_AREA_OF_VEHICLES(MyPos.x, MyPos.y, MyPos.z, 250, 0, 0, 0, 0, 0, 0, 0); 
                       MISC::CLEAR_AREA_OF_PEDS(MyPos.x, MyPos.y, MyPos.z, 250, 0); 
                       MISC::CLEAR_AREA_OF_PROJECTILES(MyPos.x, MyPos.y, MyPos.z, 250, 0);
                       MISC::CLEAR_AREA_LEAVE_VEHICLE_HEALTH(MyPos.x, MyPos.y, MyPos.z, 250, 0, 0, 0, 0);
                       PRINT("Area: ~g~Cleaned", 2000);  
                    break;         	     
             }
	}
   	resetVars();
	return true;
        }
}

extern "C" void _main(void) {
	if (!init) {
		initLibs();
		init = true;
	}

	int newFrameCount = MISC::GET_FRAME_COUNT();
	if (newFrameCount > frameCount) {
		frameCount = newFrameCount;
                Hook();		
	}
}
