#!/bin/bash

cd gtaPayload && make clean && make && cd .. && make clean && make
