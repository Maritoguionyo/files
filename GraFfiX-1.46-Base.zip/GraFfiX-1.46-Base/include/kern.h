#ifndef KERNEL_UTILS_H
#define KERNEL_UTILS_H

#include "fw_defines.h"
#include "ps4.h"

struct kpayload_get_fw_version_info_ex {
  uint64_t uaddr;
};

struct kpayload_get_fw_version_args_ex {
  void *syscall_handler;
  struct kpayload_get_fw_version_info_ex *kpayload_get_fw_version_info_ex;
};

struct kpayload_jailbreak_info_ex {
  uint64_t fw_version;
};

struct kpayload_jailbreak_args_ex {
  void *syscall_handler;
  struct kpayload_jailbreak_info_ex *kpayload_jailbreak_info_ex;
};


uint64_t get_fw_version_ex(void);
int Unjail(uint64_t fw_version);

#endif