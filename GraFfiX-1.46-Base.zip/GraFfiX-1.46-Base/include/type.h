#pragma once

#include <types.h>

#define TRUE 1
#define FALSE 0

#define Inline static inline __attribute__((always_inline))

typedef char BOOL;
typedef unsigned char u8;